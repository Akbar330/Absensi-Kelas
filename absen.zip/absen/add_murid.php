<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Siswa</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            background: linear-gradient(45deg, #1d1f20, #2a2c2d, #1d1f20, #2a2c2d);
            background-size: 400% 400%;
            animation: gradientAnimation 15s ease infinite;
            color: #ffffff;
        }

        @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .container {
            margin-top: 50px;
        }

        .card {
            background-color: #2a2c2d;
            border: none;
        }

        .card-header, .card-footer {
            background-color: #1d1f20;
        }

        .btn-custom {
            background: linear-gradient(45deg, #6b00b6, #440074);
            border: none;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-custom:hover {
            background: linear-gradient(45deg, #440074, #6b00b6);
            transform: scale(1.05);
        }
    </style>
</head>
<body>

<div class="container">
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <h2 class="text-center mb-4">Tambah Siswa</h2>
            <div class="card">
                <div class="card-header">
                    <h4>Formulir Siswa Baru</h4>
                </div>
                <div class="card-body">
                    <form id="addStudentForm">
                        <div class="form-group">
                            <label for="studentName">Nama Siswa</label>
                            <input type="text" class="form-control" id="studentName" name="studentName" required>
                        </div>
                        <button type="submit" class="btn btn-custom">Tambah Siswa</button>
                    </form>
                </div>
                <div class="card-footer text-right">
                    <a href="dashboard.php" class="btn btn-custom">Kembali ke Dashboard</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<!-- Custom JS -->
<script>
    document.getElementById('addStudentForm').addEventListener('submit', function(e) {
        e.preventDefault();
        let studentName = document.getElementById('studentName').value;

        fetch('add_student.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ studentName })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Siswa berhasil ditambahkan!');
                document.getElementById('addStudentForm').reset();
            } else {
                alert('Gagal menambahkan siswa: ' + data.error);
            }
        });
    });
</script>

</body>
</html>
