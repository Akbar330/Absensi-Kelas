<?php
session_start(); // Mulai sesi

// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "school_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Memproses form pendaftaran
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user = $_POST['username'];
    $pass = md5($_POST['password']); // Menggunakan MD5 untuk enkripsi password
    $confirm_pass = md5($_POST['confirm_password']); // Enkripsi konfirmasi password

    // Memeriksa apakah password dan konfirmasi password cocok
    if ($pass != $confirm_pass) {
        echo "Password dan konfirmasi password tidak cocok!";
    } else {
        // Memeriksa apakah username sudah ada
        $sql = "SELECT * FROM users WHERE username='$user'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "Username sudah digunakan!";
        } else {
            // Menambahkan user baru ke database
            $sql = "INSERT INTO users (username, password) VALUES ('$user', '$pass')";
            if ($conn->query($sql) === TRUE) {
                $_SESSION['username'] = $user; // Simpan username ke dalam sesi
                header("Location: index.php"); // Arahkan ke halaman utama
                exit();
            } else {
                echo "Terjadi kesalahan saat mendaftarkan pengguna baru!";
            }
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            background: linear-gradient(45deg, #1d1f20, #2a2c2d, #1d1f20, #2a2c2d);
            background-size: 400% 400%;
            animation: gradientAnimation 15s ease infinite;
            color: #ffffff;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .card {
            background-color: #2a2c2d;
            border: none;
            padding: 20px;
            border-radius: 10px;
        }

        .btn-custom {
            background: linear-gradient(45deg, #6b00b6, #440074);
            border: none;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-custom:hover {
            background: linear-gradient(45deg, #440074, #6b00b6);
            transform: scale(1.05);
        }
    </style>
</head>
<body>

<div class="card">
    <div class="card-body">
        <h3 class="card-title text-center mb-4">Register</h3>
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        <form method="post" action="register.php">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <div class="form-group">
                <label for="confirm_password">Confirm Password</label>
                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
            </div>
            <button type="submit" class="btn btn-custom btn-block">Register</button>
        </form>
    </div>
</div>

</body>
</html>
