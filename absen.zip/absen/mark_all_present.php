<?php
$host = 'localhost';
$db = 'school_db';
$user = 'root';
$pass = '';

// Create connection
$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get all students
$sql = "SELECT id FROM students";
$result = $conn->query($sql);

$date = date('Y-m-d');
$success = true;

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $studentId = $row['id'];
        // Check if record exists
        $checkSql = "SELECT * FROM attendance WHERE student_id = $studentId AND date = '$date'";
        $checkResult = $conn->query($checkSql);

        if ($checkResult->num_rows > 0) {
            // Update existing record
            $updateSql = "UPDATE attendance SET status = 'Hadir' WHERE student_id = $studentId AND date = '$date'";
            if (!$conn->query($updateSql)) {
                $success = false;
                break;
            }
        } else {
            // Insert new record
            $insertSql = "INSERT INTO attendance (student_id, date, status) VALUES ($studentId, '$date', 'Hadir')";
            if (!$conn->query($insertSql)) {
                $success = false;
                break;
            }
        }
    }
}

echo json_encode(['success' => $success]);

$conn->close();
?>
