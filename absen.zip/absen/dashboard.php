<?php
session_start(); // Mulai sesi

// Memeriksa apakah user sudah login
if (!isset($_SESSION['username'])) {
    header("Location: index.php"); // Arahkan ke halaman login jika belum login
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Absen Kelas</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            background: linear-gradient(45deg, #1d1f20, #2a2c2d, #1d1f20, #2a2c2d);
            background-size: 400% 400%;
            animation: gradientAnimation 15s ease infinite;
            color: #ffffff;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
        }

        @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .navbar-custom {
            background-color: #1d1f20;
            border-radius: 10px;
            margin-top: 20px;
            padding: 10px;
        }

        .navbar-custom .nav-link {
            color: #ffffff !important;
        }

        .container {
            margin-top: 70px;
        }

        .card {
            background-color: #2a2c2d;
            border: none;
        }

        .card-header, .card-footer {
            background-color: #1d1f20;
        }

        .btn-custom {
            background: linear-gradient(45deg, #6b00b6, #440074);
            border: none;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-custom:hover {
            background: linear-gradient(45deg, #440074, #6b00b6);
            transform: scale(1.05);
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">Absen Kelas</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link" href="#"><?php echo $_SESSION['username']; ?></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">Logout</a>
            </li>
        </ul>
    </div>
</nav>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h2 class="text-center mb-4">Dashboard Absen Kelas</h2>
            <div class="card">
                <div class="card-header">
                    <h4>Daftar Siswa</h4>
                </div>
                <div class="card-body">
                    <table class="table table-dark table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Nama Siswa</th>
                                <th>Status Kehadiran</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="studentList">
                            <!-- Data siswa akan dimuat di sini melalui JavaScript -->
                        </tbody>
                    </table>
                </div>
                <div class="card-footer text-right">
                    <button class="btn btn-custom" onclick="markAllPresent()">Tandai Semua Hadir</button>
                    <a class="btn btn-custom" href="add_murid.php">Tambah Siswa</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<!-- Custom JS -->
<script src="js/script.js"></script>
</body>
</html>
