<?php
$host = 'localhost';
$db = 'school_db';
$user = 'root';
$pass = '';

// Create connection
$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get students and their attendance status for today
$date = date('Y-m-d');
$sql = "SELECT students.id, students.name, IFNULL(attendance.status, 'Belum Absen') as status
        FROM students
        LEFT JOIN attendance ON students.id = attendance.student_id AND attendance.date = '$date'";
$result = $conn->query($sql);

$students = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $students[] = $row;
    }
}

echo json_encode($students);

$conn->close();
?>
