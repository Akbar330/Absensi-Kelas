<?php
session_start(); // Mulai sesi

// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "school_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Mendapatkan data dari form
$user = $_POST['username'];
$pass = md5($_POST['password']); // Menggunakan MD5 untuk enkripsi password

// Memeriksa apakah username dan password sesuai
$sql = "SELECT * FROM users WHERE username='$user' AND password='$pass'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $_SESSION['username'] = $user; // Simpan username ke dalam sesi
    header("Location: dashboard.php"); // Arahkan ke halaman utama
    exit();
} else {
    echo "Invalid username or password!";
}

$conn->close();
?>