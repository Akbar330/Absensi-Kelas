document.addEventListener('DOMContentLoaded', function() {
    fetch('get_students.php')
        .then(response => response.json())
        .then(data => {
            let studentList = document.getElementById('studentList');
            data.forEach((student, index) => {
                let row = document.createElement('tr');
                row.innerHTML = `
                    <td>${index + 1}</td>
                    <td>${student.name}</td>
                    <td>${student.status}</td>
                    <td>
                        <button class="btn btn-custom" onclick="markAttendance(${student.id}, 'Hadir')">Tandai Hadir</button>
                        <button class="btn btn-custom" onclick="markAttendance(${student.id}, 'Tidak Hadir')">Tandai Tidak Hadir</button>
                    </td>
                `;
                studentList.appendChild(row);
            });
        });
});

// Tandai kehadiran siswa
function markAttendance(studentId, status) {
    fetch('mark_attendance.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ studentId, status })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert('Gagal menandai kehadiran');
        }
    });
}

// Tandai semua siswa hadir
function markAllPresent() {
    fetch('mark_all_present.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert('Gagal menandai semua kehadiran');
        }
    });
}